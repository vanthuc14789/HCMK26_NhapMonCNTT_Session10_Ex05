# 🌱 🚀 Smart-Farm – Hệ thống tưới Lan thông minh

> *Smart-Farm ứng dụng IoT để theo dõi môi trường và hỗ trợ tưới nước cho trang trại Lan an toàn, tiết kiệm.*

## 1. Giới thiệu dự án

Smart-Farm thu thập dữ liệu từ cảm biến, xử lý dữ liệu trên bộ điều khiển và quyết định khi nào cần tưới. Người nông dân có thể theo dõi nhiệt độ, độ ẩm đất và trạng thái máy bơm.

Hệ thống là mô hình minh họa. Ngưỡng tưới và thiết bị cần được kiểm tra, hiệu chỉnh theo điều kiện thực tế của vườn Lan.

## 2. Hướng dẫn cài đặt

### 2.1. Thiết bị cần có

- Raspberry Pi hoặc bộ điều khiển tương thích.
- Cảm biến nhiệt độ/độ ẩm không khí và cảm biến độ ẩm đất.
- Mạch relay phù hợp với máy bơm.
- Nguồn điện đúng thông số của từng thiết bị.
- Kết nối mạng nếu cần giám sát từ xa.

### 2.2. Cài đặt môi trường

Mở Terminal và kiểm tra Python:

```bash
python3 --version
```

Tạo môi trường ảo và cài các thư viện ví dụ:

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install gpiozero
```

Trên Windows, kích hoạt môi trường ảo bằng `.venv\\Scripts\\activate`. Lệnh điều khiển GPIO chỉ chạy trên phần cứng và hệ điều hành tương thích. Hãy cài thêm thư viện cảm biến đúng với mẫu thiết bị đang dùng.

### 2.3. Chạy chương trình

Lưu chương trình vào `smart_farm.py`, kiểm tra cấu hình chân GPIO và ngưỡng tưới trước khi chạy:

```bash
python smart_farm.py
```

Không nối máy bơm trực tiếp vào chân GPIO. Dùng mạch điều khiển phù hợp, có bảo vệ điện và kiểm tra hệ thống khi máy bơm chưa nối tải.

## 3. Tính năng

- [ ] Đọc dữ liệu nhiệt độ và độ ẩm từ cảm biến.
- [ ] So sánh độ ẩm đất với ngưỡng tưới đã cấu hình.
- [ ] Bật/tắt máy bơm thông qua mạch relay phù hợp.
- [ ] Hiển thị trạng thái hoạt động cho người vận hành.
- [ ] Lưu nhật ký để theo dõi và tìm lỗi.
- [ ] Kiểm tra cảnh báo khi cảm biến mất kết nối hoặc dữ liệu bất thường.

## 4. Bảng thông số tham khảo

| Thành phần | Thông số / vai trò | Ghi chú |
|---|---|---|
| Cảm biến nhiệt độ | Ví dụ: DHT22 | Chọn theo môi trường và yêu cầu độ chính xác |
| Cảm biến độ ẩm đất | Loại điện dung hoặc loại phù hợp | Hiệu chuẩn theo loại đất và giá thể |
| Bộ điều khiển | Raspberry Pi hoặc thiết bị tương thích | Cần kiểm tra chân giao tiếp |
| Mạch relay | Theo điện áp và dòng tải của máy bơm | Không điều khiển tải công suất lớn trực tiếp bằng GPIO |
| Máy bơm | Theo thiết kế hệ thống tưới | Dùng nguồn riêng đúng định mức |
| Kết nối | Wi-Fi hoặc LAN | Cần thiết nếu có giám sát từ xa |
| Ngưỡng tưới | Ví dụ: độ ẩm đất dưới 30% | Giá trị minh họa, phải hiệu chỉnh thực tế |

## 5. Sơ đồ hệ thống

![Sơ đồ hệ thống Smart-Farm: cảm biến gửi dữ liệu đến bộ điều khiển, bộ điều khiển ra lệnh qua relay để vận hành máy bơm; dữ liệu có thể gửi lên màn hình hoặc đám mây.](images/so-do-smart-farm.svg)

Luồng cơ bản: **Cảm biến → Bộ điều khiển/SoC → Mạch relay → Máy bơm**. Dữ liệu trạng thái có thể được gửi đến giao diện giám sát.

## 6. CPU xử lý lệnh tưới theo chu kỳ Fetch–Decode–Execute

> 1. **Fetch (Lấy lệnh):** CPU lấy lệnh tiếp theo của chương trình từ bộ nhớ.
> 2. **Decode (Giải mã):** CPU giải mã lệnh để xác định thao tác cần thực hiện.
> 3. **Execute (Thực thi):** CPU thực hiện phép tính hoặc thao tác, chẳng hạn so sánh giá trị độ ẩm với ngưỡng và yêu cầu bộ điều khiển bật/tắt relay.
>
> Chu kỳ này diễn ra liên tục khi chương trình chạy. Lệnh bật máy bơm vẫn phải đi qua phần mềm và mạch điều khiển phù hợp; CPU không cấp điện trực tiếp cho máy bơm.

## 7. Mô hình DIKW: từ dữ liệu đến hành động

1. **Data – Dữ liệu:** Cảm biến ghi nhận nhiệt độ `32°C` và độ ẩm đất `25%`.
2. **Information – Thông tin:** Hệ thống xác định nhiệt độ đang cao và độ ẩm đất thấp hơn ngưỡng cài đặt `30%`.
3. **Knowledge – Kiến thức:** Theo quy tắc đã hiệu chỉnh cho vườn Lan, đất dưới ngưỡng có thể cần được tưới; cần kiểm tra cảm biến và điều kiện thực tế.
4. **Wisdom – Trí tuệ / quyết định:** Hệ thống quyết định bật máy bơm trong thời gian giới hạn, theo dõi lại độ ẩm và dừng tưới khi đạt điều kiện an toàn.

```text
             /----------------------\
            /  WISDOM – Quyết định   \
           /--------------------------\
          / KNOWLEDGE – Quy tắc tưới  \
         /------------------------------\
        / INFORMATION – Ý nghĩa dữ liệu  \
       /----------------------------------\
      / DATA – Giá trị cảm biến thô        \
     /--------------------------------------\
```

Các giá trị trên chỉ là ví dụ. Nhiệt độ cao không tự động có nghĩa là cần tưới; quyết định nên dựa vào độ ẩm đất, ngưỡng được hiệu chuẩn và giới hạn an toàn.

## 8. Kiến thức SoC và IPO

- **SoC (System on a Chip):** Một chip tích hợp nhiều thành phần của hệ thống, có thể gồm CPU và các bộ điều khiển ngoại vi. Cấu hình cụ thể phụ thuộc thiết bị.
- **IPO (Input – Process – Output):**
  - **Input:** Nhiệt độ, độ ẩm đất, cấu hình và lệnh người dùng.
  - **Process:** Bộ điều khiển đọc dữ liệu, CPU chạy chương trình và so sánh với ngưỡng.
  - **Output:** Hiển thị thông số, cập nhật nhật ký và điều khiển relay/máy bơm.

## 9. Lưu ý an toàn và xử lý khi RAM đầy

Nếu RAM tăng cao do chương trình ghi nhật ký quá nhiều, hệ thống có thể chậm hoặc dừng hoạt động. Thực hiện theo thứ tự an toàn:

1. Kiểm tra mức sử dụng RAM bằng `free -h` trên Linux hoặc `top`.
2. Xác định tiến trình gây tăng RAM; không kết thúc tiến trình hệ thống một cách tùy tiện.
3. Kiểm tra cấu hình ghi log. Dùng xoay vòng nhật ký (log rotation), giới hạn dung lượng và thời gian lưu.
4. Không lưu toàn bộ nhật ký vào một biến hoặc danh sách trong RAM; ghi theo từng dòng hoặc theo lô nhỏ.
5. Sao lưu log cần thiết trước khi dọn dẹp. Không dùng lệnh xóa hàng loạt như `rm -rf` khi chưa xác minh đường dẫn.
6. Nếu máy bơm đang chạy, chuyển hệ thống về trạng thái an toàn theo quy trình vận hành trước khi khởi động lại chương trình.
7. Chỉ khởi động lại dịch vụ khi đã xác định nguyên nhân và có thể kiểm tra lại cảm biến, relay, máy bơm sau đó.

**Khuyến nghị:** Đặt cảnh báo khi RAM vượt ngưỡng vận hành đã kiểm thử, giới hạn kích thước log và kiểm tra trạng thái máy bơm độc lập với việc ghi log.

## 10. Kiểm thử trước khi bàn giao

- [ ] So sánh số đo cảm biến với thiết bị đo tham chiếu.
- [ ] Thử tình huống độ ẩm thấp hơn ngưỡng.
- [ ] Thử tình huống độ ẩm bằng hoặc cao hơn ngưỡng.
- [ ] Kiểm tra máy bơm dừng khi chương trình kết thúc hoặc gặp lỗi.
- [ ] Kiểm tra mất kết nối cảm biến và phản ứng an toàn.
- [ ] Kiểm tra nhật ký có giới hạn dung lượng và RAM ổn định.
- [ ] Hướng dẫn người vận hành cách dừng hệ thống khẩn cấp.

## 11. Thông tin nộp bài

Tên repository theo mẫu:

`[Tên Lớp]_[Môn Học]_Session08_Ex05`

Ví dụ:

`HCMKS26CNTT2_IT101_Session08_Ex05`
